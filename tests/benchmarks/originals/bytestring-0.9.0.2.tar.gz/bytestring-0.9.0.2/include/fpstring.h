
void fps_reverse(unsigned char *dest, unsigned char *from, unsigned long  len);
void fps_intersperse(unsigned char *dest, unsigned char *from, unsigned long  len, unsigned char c);
unsigned char fps_maximum(unsigned char *p, unsigned long  len);
unsigned char fps_minimum(unsigned char *p, unsigned long  len);
unsigned long fps_count(unsigned char *p, unsigned long  len, unsigned char w);
