
#include "HsBase.h"
void hsFD_ZERO(fd_set *fds) { FD_ZERO(fds); }
